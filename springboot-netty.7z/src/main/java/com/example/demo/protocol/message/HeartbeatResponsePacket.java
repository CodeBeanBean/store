package com.example.demo.protocol.message;

import com.example.demo.protocol.message.command.Command;

/**
 *  
 * @create 2018-10-25 16:16
 */
public class HeartbeatResponsePacket extends Packet {

    @Override
    public Byte getCommand() {
        return Command.HEARTBEAT_RESPONSE;
    }
}
