package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootNettyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootNettyApplication.class, args);
	}

}
