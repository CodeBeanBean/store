﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private BindingSource bindingSource1 = new BindingSource();


        public Form1()
        {
            InitializeComponent();
            this.Load += new EventHandler(Form1_Load);
        }

        private DummyDoc CreateNewDocument(string text)
        {
            DummyDoc dummyDoc = new DummyDoc();
            dummyDoc.Text = text;
            return dummyDoc;
        }

        private void CloseAllDocuments()
        {
            if (dockPanel1.DocumentStyle == DocumentStyle.SystemMdi)
            {
                foreach (Form form in MdiChildren)
                    form.Close();
            }
            else
            {
                for (int index = dockPanel1.Contents.Count - 1; index >= 0; index--)
                {
                    if (dockPanel1.Contents[index] is IDockContent)
                    {
                        IDockContent content = (IDockContent)dockPanel1.Contents[index];
                        content.DockHandler.Close();
                    }
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DataTable dt = GetTargetDatas();
            FillDataGridViewWithDataSource(dataGridView1, dt);

            dockPanel1.SuspendLayout(true);

            CloseAllDocuments();
            DummyDoc doc1 = CreateNewDocument("Document1");
            DummyDoc doc2 = CreateNewDocument("Document2");
            DummyDoc doc3 = CreateNewDocument("Document3");
            DummyDoc doc4 = CreateNewDocument("Document4");
            doc1.Show(dockPanel1, DockState.Document);
            doc2.Show(doc1.Pane, null);
            doc3.Show(doc1.Pane, DockAlignment.Bottom, 0.5);
            doc4.Show(doc3.Pane, DockAlignment.Right, 0.5);

            dockPanel1.ResumeLayout(true, true);
        }


        private void FillDataGridViewWithDataSource(DataGridView dataGridView, DataTable dTable) {
            dataGridView.Rows.Clear();
            if (dTable != null && dTable.Rows.Count > 0) {
                dataGridView.Columns["Column1"].DataPropertyName = "Column1";
                dataGridView.Columns["Column2"].DataPropertyName = "Column2";
                dataGridView.Columns["Column3"].DataPropertyName = "Column3";
            }
            dataGridView.DataSource = dTable;
            dataGridView.AutoGenerateColumns = false;
        }


        private DataTable GetTargetDatas()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Column1", typeof(String));
            dt.Columns.Add("Column2", typeof(String));
            dt.Columns.Add("Column3", typeof(String));
            dt.Rows.Add("test1", "test2", "test3");
            return dt;
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = "D:\\";
            openFileDialog.Filter = "txt files (*.txt,*.*)|*.txt;*.*";
            openFileDialog.FilterIndex = 1;
            openFileDialog.RestoreDirectory = true;
            openFileDialog.Title = "Open";
            openFileDialog.ShowDialog();
        }

    }
}
