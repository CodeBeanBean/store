using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace WindowsFormsApp1
{
    public partial class DummyTable5 : DockContent
    {
        public DummyTable5()
        {
            InitializeComponent();
            DataTable dt = GetTargetDatas();
            FillDataGridViewWithDataSource(this.myDataGridView1, dt);
        }


        private void FillDataGridViewWithDataSource(DataGridView dataGridView, DataTable dTable)
        {
            dataGridView.Rows.Clear();
            if (dTable != null && dTable.Rows.Count > 0)
            {
                for (int i = 1; i < 8; i++)
                {
                    dataGridView.Columns["Column" + i].DataPropertyName = "Column" + i;
                }


            }
            dataGridView.DataSource = dTable;
            dataGridView.AutoGenerateColumns = false;
        }


        private DataTable GetTargetDatas()
        {
            DataTable dt = new DataTable();
            for (int i = 1; i < 8; i++)
            {
                dt.Columns.Add("Column" + i, typeof(String));
            }


            for (int i = 0; i < 200; i++)
                dt.Rows.Add("案件No" + i, "案件" + i, "" + i, "20200205" + i, "7400" + i);

            Type type = myDataGridView1.GetType();
            PropertyInfo pi = type.GetProperty("DoubleBuffered", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            pi.SetValue(myDataGridView1, true, null);

            return dt;
        }

    }


}

