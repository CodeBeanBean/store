using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using System.IO;
using System.Drawing.Drawing2D;

namespace WindowsFormsApp1
{
    public partial class DummyTable : DockContent
    {
        public int rowFlag = 0;
        public DummyTable()
        {
            InitializeComponent();
            DataTable dt = GetTargetDatas();
            FillDataGridViewWithDataSource(this.dataGridView1, dt);
        }


        private void FillDataGridViewWithDataSource(DataGridView dataGridView, DataTable dTable)
        {
            dataGridView.Rows.Clear();
            if (dTable != null && dTable.Rows.Count > 0)
            {
                for (int i=1;i<21;i++) {
                    dataGridView.Columns["Column"+i].DataPropertyName = "Column"+i;
                }
                
               
            }
            dataGridView.DataSource = dTable;
            dataGridView.AutoGenerateColumns = false;
        }


        private DataTable GetTargetDatas()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Column1", typeof(String));
            dt.Columns.Add("Column2", typeof(String));
            dt.Columns.Add("Column3", typeof(String));
            dt.Columns.Add("Column4", typeof(String));
            dt.Columns.Add("Column5", typeof(String));
            dt.Columns.Add("Column6", typeof(String));
            dt.Columns.Add("Column7", typeof(String));
            dt.Columns.Add("Column8", typeof(String));
            dt.Columns.Add("Column9", typeof(String));
            dt.Columns.Add("Column10", typeof(String));
            dt.Columns.Add("Column11", typeof(String));
            dt.Columns.Add("Column12", typeof(String));
            dt.Columns.Add("Column13", typeof(String));
            dt.Columns.Add("Column14", typeof(String));
            dt.Columns.Add("Column15", typeof(String));
            dt.Columns.Add("Column16", typeof(String));
            dt.Columns.Add("Column17", typeof(String));
            dt.Columns.Add("Column18", typeof(String));
            dt.Columns.Add("Column19", typeof(String));
            dt.Columns.Add("Column20", typeof(String));


            for (int i = 0; i < 999; i++)
                dt.Rows.Add("����" + i, "20200205" + i, "" + i, "��Ʒ�N�e" + i, "7400" + i, "1" + i, "0" + i, "0" + i, "0" + i, "0" + i, "1" + i, "" + i, "" + i, "" + i, "" + i, "" + i, "" + i, "test" + i, "" + i, "" + i);


            return dt;
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            rowFlag = 1;
            if (e.Button == MouseButtons.Right)
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                {
                    //��������ѡ��״̬�Ͳ��ٽ�������
                    /*if (dataGridView1.Rows[e.RowIndex].Selected == false)
                    {
                        dataGridView1.ClearSelection();
                        dataGridView1.Rows[e.RowIndex].Selected = true;
                    }*/
                    this.dataGridView1.CurrentCell = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex];
                    //���������˵�
                    contextMenuStrip1.Show(MousePosition.X, MousePosition.Y);
                }
            }
            //this.dataGridView1.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dataGridView1_CellPainting);
            this.dataGridView1.Refresh();

            //this.dataGridView1.Rows[e.RowIndex].DefaultCellStyle
            //this.dataGridView1.Paint += new System.Windows.Forms.PaintEventHandler(this.dataGridView1_Paint);
        }

        private void dataGridView1_Paint(object sender, PaintEventArgs e)
        {
            DataGridViewCell cell = this.dataGridView1.CurrentCell;
            if (!this.dataGridView1.ContainsFocus || cell == null)
                return;
            /*Rectangle bounds = this.GetCellBounds(cell);
            bounds.X += 1;
            bounds.Y += 1;
            bounds.Width -= 2;
            bounds.Height -= 2;*/
            // ControlPaint.DrawReversibleFrame(bounds, Color.Red, FrameStyle.Thick);
            Rectangle bounds = Rectangle.Empty;
            bounds.Y = this.dataGridView1.GetCellDisplayRectangle(cell.ColumnIndex, cell.RowIndex, false).Top;
            bounds.Width = this.dataGridView1.GetCellDisplayRectangle(cell.ColumnIndex, this.dataGridView1.CurrentCell.RowIndex, false).Width - 2;
            bounds.Height = this.dataGridView1.GetCellDisplayRectangle(cell.ColumnIndex, this.dataGridView1.CurrentCell.RowIndex, true).Height - 2;
            DataGridViewRow row = cell.DataGridView.Rows[cell.RowIndex];
            Pen penBlue = new Pen(Color.Blue);
            for (int cellIndex = 0; cellIndex < row.Cells.Count; cellIndex++)
            {
                bounds.X = this.dataGridView1.GetCellDisplayRectangle(cellIndex, 0, false).Left;
                e.Graphics.DrawRectangle(penBlue, bounds);
            }
            //
            /*bounds.X = this.dataGridView1.GetCellDisplayRectangle(cell.ColumnIndex, cell.RowIndex, false).Left;


            Pen pen = new Pen(Color.Yellow)
            {
                DashStyle = DashStyle.Dot
            };
            Console.WriteLine(bounds.X + ";" + bounds.Y + ";" + bounds.Width + ";" + bounds.Height);
            e.Graphics.DrawRectangle(pen, bounds);*/
            // pen blue
            //GetRowBounds(cell, sender, e);
        }

        private Rectangle GetCellBounds(DataGridViewCell cell)
        {
            if (cell == null || cell.DataGridView == null)
                return Rectangle.Empty;
            Rectangle bounds = Rectangle.Empty;

            bounds.Width = cell.DataGridView.Columns[cell.ColumnIndex].Width;
            bounds.Height = cell.DataGridView.Rows[cell.RowIndex].Height;

            if (cell.DataGridView.RowHeadersVisible)
                bounds.X += cell.DataGridView.RowHeadersWidth;
            DataGridViewRow row = cell.DataGridView.Rows[cell.RowIndex];
            for (int cellIndex = 0; cellIndex < row.Cells.Count; cellIndex++)
            {
                if (cellIndex < cell.ColumnIndex)
                    bounds.X += cell.DataGridView.Columns[cellIndex].Width;
            }

            if (cell.DataGridView.ColumnHeadersVisible)
                bounds.Y += cell.DataGridView.ColumnHeadersHeight;
            for (int rowIndex = 0; rowIndex < cell.DataGridView.Rows.Count; rowIndex++)
            {
                if (rowIndex < cell.RowIndex)
                    bounds.Y += row.Height;
            }
            return bounds;
        }

        private void wordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowColor = true;
            fontDialog1.ShowDialog();
            this.dataGridView1.CurrentCell.Style.Font = fontDialog1.Font;
            this.dataGridView1.CurrentCell.Style.ForeColor = fontDialog1.Color;
        }

        private void backColocToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = colorDialog1.ShowDialog();
            if (dr == DialogResult.OK)
            {
                this.dataGridView1.CurrentCell.Style.BackColor = colorDialog1.Color;
            }
        }

        private void DummyTable_Load(object sender, EventArgs e)
        {
            //this.dataGridView1.CurrentCell = null;
            //this.dataGridView1.Refresh();
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //this.dataGridView1.ClearSelection();
        }

        private void dataGridView1_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (rowFlag == 1)
            {
                if (e.RowIndex == this.dataGridView1.CurrentCell.RowIndex
                && e.ColumnIndex >= 0)
                {
                    Rectangle newRect = new Rectangle(e.CellBounds.X + 1,
                        e.CellBounds.Y + 1, e.CellBounds.Width - 4,
                        e.CellBounds.Height - 4);

                    using (
                        Brush gridBrush = new SolidBrush(this.dataGridView1.GridColor),
                        backColorBrush = new SolidBrush(Color.FromArgb(250, 250, 250)))
                    {
                        using (Pen gridLinePen = new Pen(gridBrush))
                        {
                            // Erase the cell.
                            e.Graphics.FillRectangle(backColorBrush, e.CellBounds);

                            // Draw the grid lines (only the right and bottom lines;
                            // DataGridView takes care of the others).
                            e.Graphics.DrawLine(gridLinePen, e.CellBounds.Left,
                                e.CellBounds.Bottom - 1, e.CellBounds.Right - 1,
                                e.CellBounds.Bottom - 1);
                            e.Graphics.DrawLine(gridLinePen, e.CellBounds.Right - 1,
                                e.CellBounds.Top, e.CellBounds.Right - 1,
                                e.CellBounds.Bottom);

                            // Draw the inset highlight box.
                            if (e.ColumnIndex == this.dataGridView1.CurrentCell.ColumnIndex)
                            {
                                Pen pen = new Pen(Color.FromArgb(255, 255, 0))
                                {
                                    DashStyle = DashStyle.Dash
                                };
                                e.Graphics.DrawRectangle(pen, newRect);
                            }
                            else
                            {
                                e.Graphics.DrawRectangle(Pens.Blue, newRect);
                            }

                            // Draw the text content of the cell, ignoring alignment.
                            if (e.Value != null)
                            {
                                e.Graphics.DrawString((String)e.Value, e.CellStyle.Font,
                                    Brushes.Black, e.CellBounds.X + 2,
                                    e.CellBounds.Y + 2, StringFormat.GenericDefault);
                            }
                            e.Handled = true;
                        }
                    }
                }
            }
            else if (rowFlag == 2)
            {
                if (e.ColumnIndex == this.dataGridView1.CurrentCell.ColumnIndex
                && e.RowIndex >= 0)
                {
                    Rectangle newRect = new Rectangle(e.CellBounds.X + 1,
                        e.CellBounds.Y + 1, e.CellBounds.Width - 4,
                        e.CellBounds.Height - 4);

                    using (
                        Brush gridBrush = new SolidBrush(this.dataGridView1.GridColor),
                        backColorBrush = new SolidBrush(Color.FromArgb(250, 250, 250)))
                    {
                        using (Pen gridLinePen = new Pen(gridBrush))
                        {
                            // Erase the cell.
                            e.Graphics.FillRectangle(backColorBrush, e.CellBounds);

                            // Draw the grid lines (only the right and bottom lines;
                            // DataGridView takes care of the others).
                            e.Graphics.DrawLine(gridLinePen, e.CellBounds.Left,
                                e.CellBounds.Bottom - 1, e.CellBounds.Right - 1,
                                e.CellBounds.Bottom - 1);
                            e.Graphics.DrawLine(gridLinePen, e.CellBounds.Right - 1,
                                e.CellBounds.Top, e.CellBounds.Right - 1,
                                e.CellBounds.Bottom);

                            // Draw the inset highlight box.
                            if (e.RowIndex == this.dataGridView1.CurrentCell.RowIndex)
                            {
                                Pen pen = new Pen(Color.FromArgb(255, 255, 0))
                                {
                                    DashStyle = DashStyle.Dot
                                };
                                e.Graphics.DrawRectangle(pen, newRect);
                            }
                            else
                            {
                                e.Graphics.DrawRectangle(Pens.Blue, newRect);
                            }

                            // Draw the text content of the cell, ignoring alignment.
                            if (e.Value != null)
                            {
                                e.Graphics.DrawString((String)e.Value, e.CellStyle.Font,
                                    Brushes.Black, e.CellBounds.X + 2,
                                    e.CellBounds.Y + 2, StringFormat.GenericDefault);
                            }
                            e.Handled = true;
                        }
                    }
                }
            }
        }

        private void dataGridView1_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            rowFlag = 2;
            this.dataGridView1.CurrentCell = this.dataGridView1.Rows[0].Cells[e.ColumnIndex];
            this.dataGridView1.Rows[0].Selected = false;
            this.dataGridView1.Refresh();
        }
    }


}