using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using System.IO;
using System.Reflection;

namespace WindowsFormsApp1
{
    public partial class DummyTableTest : DockContent
    {
        public DummyTableTest()
        {
            InitializeComponent();
            DataTable dt = GetTargetDatas();
            FillDataGridViewWithDataSource(this.myDataGridView1,dt);
        }


        private void FillDataGridViewWithDataSource(DataGridView dataGridView, DataTable dTable)
        {
            dataGridView.Rows.Clear();
            if (dTable != null && dTable.Rows.Count > 0)
            {
                dataGridView.Columns["Column1"].DataPropertyName = "Column1";
                dataGridView.Columns["Column2"].DataPropertyName = "Column2";
                dataGridView.Columns["Column3"].DataPropertyName = "Column3";
                dataGridView.Columns["Column4"].DataPropertyName = "Column4";
                dataGridView.Columns["Column5"].DataPropertyName = "Column5";
                dataGridView.Columns["Column6"].DataPropertyName = "Column6";
                dataGridView.Columns["Column7"].DataPropertyName = "Column7";
                dataGridView.Columns["Column8"].DataPropertyName = "Column8";
                dataGridView.Columns["Column9"].DataPropertyName = "Column9";
                dataGridView.Columns["Column10"].DataPropertyName = "Column10";
                dataGridView.Columns["Column11"].DataPropertyName = "Column11";
                dataGridView.Columns["Column12"].DataPropertyName = "Column12";


            }
            dataGridView.DataSource = dTable;
            dataGridView.AutoGenerateColumns = false;
        }


        private DataTable GetTargetDatas()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Column1", typeof(String));
            dt.Columns.Add("Column2", typeof(String));
            dt.Columns.Add("Column3", typeof(String));
            dt.Columns.Add("Column4", typeof(String));
            dt.Columns.Add("Column5", typeof(String));
            dt.Columns.Add("Column6", typeof(String));
            dt.Columns.Add("Column7", typeof(String));
            dt.Columns.Add("Column8", typeof(String));
            dt.Columns.Add("Column9", typeof(String));
            dt.Columns.Add("Column10", typeof(String));
            dt.Columns.Add("Column11", typeof(String));
            dt.Columns.Add("Column12", typeof(String));


            //StreamReader sr = new StreamReader("");
            //string txt = sr.ReadToEnd().Replace("\r\n", "-");
            //string[] nodes = txt.Split('-');
            //dt.Columns.Add("ID", typeof(string));
            //foreach (string node in nodes)
            //{
            //    string[] strs = node.Split('-');
            //    DataRow dr = dt.NewRow();
            //    dr["ID"] = strs[0];
            //    dt.Rows.Add(dr);
            // }
            // return dt;




            for (int i = 0; i < 200; i++)
                dt.Rows.Add("����No" + i, "����" + i, "" + i, "20200205" + i, "7400" + i, "1" + i, "0" + i, "0" + i, "0" + i, "0" + i, "1" + i, "" + i);

            Type type = myDataGridView1.GetType();
            PropertyInfo pi = type.GetProperty("DoubleBuffered", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            pi.SetValue(myDataGridView1, true, null);

            return dt;
        }

    }


}