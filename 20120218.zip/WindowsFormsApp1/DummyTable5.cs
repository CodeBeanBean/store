using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using System.IO;
using System.Collections;

namespace WindowsFormsApp1
{
    public partial class DummyTable5 : DockContent
    {

        public DummyTable5()
        {
            InitializeComponent();
            DataTable dt = GetTargetDatas();
            FillDataGridViewWithDataSource(this.dataGridView1, dt);
            GetInitCombox1();
            GetInitCombox2();
        }


        private void FillDataGridViewWithDataSource(DataGridView dataGridView, DataTable dTable)
        {
           
            //dataGridView.Rows.Clear();
            this.dataGridView1.DataSource = null;
            if (dTable != null && dTable.Rows.Count > 0)
            {
                for (int i = 1; i < 29; i++)
                {
                    dataGridView.Columns["dataGridViewTextBoxColumn"+i].DataPropertyName = "dataGridViewTextBoxColumn"+i;
                
                }
                dataGridView.DataSource = dTable;
                dataGridView.AutoGenerateColumns = false;
            }
        }


        private DataTable GetTargetDatas()
        {
            DataTable dt = new DataTable();

            for (int i = 1; i < 29; i++)
            {
                dt.Columns.Add("dataGridViewTextBoxColumn" + i, typeof(String));
            }

            dt.Rows.Add("�g��kע��", "null", "��", "�kע����", "�g", "38022000002", "null", "E000000000000001", "����1", "P000000000000001", "B001", "�֥��`���`1", "����", "4307", "JP", "JPY", "F00001", "�ե����1", "null", "B", "10000", "null", "null", "null", "10000", "�|��", "20200206", "null");
            dt.Rows.Add("�g��kע��", "null", "��", "�kע����", "�g", "19011000001", "null", "E000000000000001", "����1", "P000000000000001", "B001", "�֥��`���`1", "����", "6758", "JP", "JPY", "F00001", "�ե����1", "null", "B", "5000", "null", "null", "null", "10000", "�|��", "20200206", "null");
            dt.Rows.Add("�g��kע��", "null", "��", "�kע����", "�g", "76044000004", "null", "E000000000000001", "����1", "P000000000000001", "B001", "�֥��`���`1", "����", "7974", "JP", "JPY", "F00001", "�ե����1", "null", "B", "3000", "null", "null", "null", "10000", "�|��", "20200206", "null");
            dt.Rows.Add("���饤����", "null", "��", "�kע����", "�g", "57033000003", "null", "E000000000000001", "����1", "P000000000000001", "B001", "�֥��`���`1", "����", "1301", "JP", "JPY", "F00001", "�ե����1", "null", "B", "50000", "null", "null", "null", "10000", "�|��", "20200206", "null");
            dt.Rows.Add("���饤����", "null", "��", "�kע����", "�g", "95055000005", "null", "E000000000000001", "����2", "P000000000000002", "B002", "�֥��`���`2", "����", "3222", "JP", "JPY", "F00002", "�ե����2", "null", "S", "2000", "null", "null", "null", "10000", "�|��", "20200206", "null");
            dt.Rows.Add("���饤����", "null", "��", "�kע����", "�g", "1140660000", "null", "E000000000000001", "����2", "P000000000000002", "B002", "�֥��`���`2", "����", "3222", "JP", "JPY", "F00002", "�ե����2", "null", "S", "2000", "null", "null", "null", "10000", "�|��", "20200206", "null");
            dt.Rows.Add("���饤����", "null", "��", "ָʾ�g��", "�g", "1140660000", "null", "E000000000000001", "����2", "P000000000000002", "B002", "�֥��`���`2", "����", "3222", "JP", "JPY", "F00002", "�ե����2", "null", "S", "2000", "null", "null", "null", "10000", "�|��", "20200206", "null");

            return dt;
        }
        private void GetInitCombox1()
        {
            DataTable dt = GetTargetDatas();
            DataTable dtTemporary = new DataTable();
            DataView dataview = dt.DefaultView;
            dtTemporary = dataview.ToTable(true, "dataGridViewTextBoxColumn14");



            ArrayList list = new ArrayList();

            for (int x = 0; x < dtTemporary.Rows.Count; x++)
            {
                list.Add(dtTemporary.Rows[x][0].ToString());
            }

            comboBox1.DataSource = list;

        }
        private void GetInitCombox2()
        {
            DataTable dt = GetTargetDatas();
            DataTable dtTemporary = new DataTable();
            DataView dataview = dt.DefaultView;
            dtTemporary = dataview.ToTable(true, "dataGridViewTextBoxColumn20");



            ArrayList list = new ArrayList();

            for (int x = 0; x < dtTemporary.Rows.Count; x++)
            {
                list.Add(dtTemporary.Rows[x][0].ToString());
            }

            comboBox2.DataSource = list;

        }


        

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null)
            {

            }
            else
            {
                DataTable dt = GetTargetDatas();
                DataTable TempDT = dt.Clone();
                String str = "dataGridViewTextBoxColumn14 =" + "'" + comboBox1.SelectedItem.ToString() + "'";

                DataRow[] dr = dt.Select(str);

                foreach (DataRow DR in dr)
                {
                    TempDT.ImportRow(DR);
                }

                FillDataGridViewWithDataSource(this.dataGridView1, TempDT);
            }
        }

        private void comboBox2_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (comboBox2.SelectedItem == null)
            {

            }
            else
            {
                DataTable dt = GetTargetDatas();
                DataTable TempDT = dt.Clone();
                String str = "dataGridViewTextBoxColumn20 =" + "'" + comboBox2.SelectedItem.ToString() + "'";

                DataRow[] dr = dt.Select(str);

                foreach (DataRow DR in dr)
                {
                    TempDT.ImportRow(DR);
                }

                FillDataGridViewWithDataSource(this.dataGridView1, TempDT);
            }
        }
    }

}