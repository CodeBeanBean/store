﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private BindingSource bindingSource1 = new BindingSource();
        private DeserializeDockContent m_deserializeDockContent;

        public Form1()
        {
            InitializeComponent();
            m_deserializeDockContent = new DeserializeDockContent(GetContentFromPersistString);
            this.Load += new EventHandler(Form1_Load);
        }

        private DummyTable CreateNewTable(string text)
        {
            DummyTable dummyTable = new DummyTable();
            dummyTable.Text = text;
            return dummyTable;
        }

        private DummyTable5 CreateNewTable2(string text)
        {
            DummyTable5 dummyTable2 = new DummyTable5();
            dummyTable2.Text = text;
            return dummyTable2;
        }
        private DummyTableTest CreateNewTable3(string text)
        {
            DummyTableTest dummyTable3 = new DummyTableTest();
            dummyTable3.Text = text;
            return dummyTable3;
        }

        private IDockContent GetContentFromPersistString(string persistString)
        {

            if (persistString == typeof(DummyTable).ToString()) {
                return CreateNewTable("サマリー");
            } else if (persistString == typeof(DummyTable5).ToString())
            {
                return CreateNewTable2("発注");

            } else if (persistString == typeof(DummyTableTest).ToString()) {
                return CreateNewTable3("test");
            }

            return null;

        }


        private void Form1_Load(object sender, EventArgs e)
        {
            string configFile = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "DockPanel.temp.config");


            if (File.Exists(configFile))
            {
                dockPanel1.LoadFromXml(configFile, m_deserializeDockContent);
                dockPanel1.SuspendLayout(true);
            }
            else
            {
                dockPanel1.SuspendLayout(true);


                CloseAllDocuments();
                DummyTable doc1 = CreateNewTable("Table1");
                DummyTable5 doc2 = CreateNewTable2("Table2");
                DummyTableTest doc3 = CreateNewTable3("Table3");
                DummyTable doc4 = CreateNewTable("Table4");
                DummyTable doc1_1 = CreateNewTable("Table1_1");

                doc1.Show(dockPanel1, DockState.Document);
                doc3.Show(doc1.Pane, DockAlignment.Bottom, 0.5);
                doc4.Show(doc3.Pane, DockAlignment.Left, 0.5);
                doc2.Show(doc4.Pane, DockAlignment.Right, 0.5);
                doc1_1.Show(doc2.Pane, DockAlignment.Right, 0.5);
            }

            dockPanel1.ResumeLayout(true, true);


        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = "D:\\";
            openFileDialog.Filter = "txt files (*.txt,*.*)|*.txt;*.*";
            openFileDialog.FilterIndex = 1;
            openFileDialog.RestoreDirectory = true;
            openFileDialog.Title = "Open";
            openFileDialog.ShowDialog();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            string configFile = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "DockPanel.temp.config");

            dockPanel1.SaveAsXml(configFile);
        }

        private void whiteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string configFile = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "DockPanel.temp.config");

            dockPanel1.SaveAsXml(configFile);

            CloseAllContents();

            this.dockPanel1.Theme = this.vS2015LightTheme1;


            if (File.Exists(configFile))
                dockPanel1.LoadFromXml(configFile, m_deserializeDockContent);
        }


        private void CloseAllContents()
        {

            // Close all other document windows
            CloseAllDocuments();

            // IMPORTANT: dispose all float windows.
            foreach (var window in dockPanel1.FloatWindows.ToList())
                window.Dispose();

            System.Diagnostics.Debug.Assert(dockPanel1.Panes.Count == 0);
            System.Diagnostics.Debug.Assert(dockPanel1.Contents.Count == 0);
            System.Diagnostics.Debug.Assert(dockPanel1.FloatWindows.Count == 0);
        }

        private void CloseAllDocuments()
        {
            if (dockPanel1.DocumentStyle == DocumentStyle.SystemMdi)
            {
                foreach (Form form in MdiChildren)
                    form.Close();
            }
            else
            {
                foreach (IDockContent document in dockPanel1.DocumentsToArray())
                {
                    // IMPORANT: dispose all panes.
                    document.DockHandler.DockPanel = null;
                    document.DockHandler.Close();
                }
            }
        }

        private void blackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string configFile = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "DockPanel.temp.config");

            dockPanel1.SaveAsXml(configFile);

            CloseAllContents();

            this.dockPanel1.Theme = this.vS2015DarkTheme1;


            if (File.Exists(configFile))
                dockPanel1.LoadFromXml(configFile, m_deserializeDockContent);
        }
    }
}
