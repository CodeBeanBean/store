using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace WindowsFormsApp1
{
    public partial class DummyTable5 : DockContent
    {
        public DummyTable5()
        {
            InitializeComponent();
            DataTable dt = GetTargetDatas();
            FillDataGridViewWithDataSource(this.myDataGridView1, dt);
        }


        private void FillDataGridViewWithDataSource(DataGridView dataGridView, DataTable dTable)
        {
            // dataGridView.Rows.Clear();
            dataGridView.DataSource = null;
            if (dTable != null && dTable.Rows.Count > 0)
            {
                for (int i = 1; i < 45; i++)
                {
                    dataGridView.Columns["Column" + i].DataPropertyName = "Column" + i;
                }


            }
            dataGridView.DataSource = dTable;
            dataGridView.AutoGenerateColumns = false;
        }


        private DataTable GetTargetDatas()
        {
            DataTable dt = new DataTable();
            for (int i = 1; i < 45; i++)
            {
                dt.Columns.Add("Column" + i, typeof(String));
            }



            dt.Rows.Add("単体発注用", "null", "■", "発注完了", "済", "38022000002", "null", "E000000000000001", "案件1", "P000000000000001", "B001", "ブローカー1", "内株", "4307", "JP", "JPY", "F00001", "ファンド1", "null", "B", "10000", "null", "null", "null", "10000", "東京", "20200206", "null");
            dt.Rows.Add("単体発注用", "null", "■", "発注完了", "済", "19011000001", "null", "E000000000000001", "案件1", "P000000000000001", "B001", "ブローカー1", "内株", "6758", "JP", "JPY", "F00001", "ファンド1", "null", "B", "5000", "null", "null", "null", "10000", "東京", "20200206", "null");
            dt.Rows.Add("単体発注用", "null", "■", "発注完了", "済", "76044000004", "null", "E000000000000001", "案件1", "P000000000000001", "B001", "ブローカー1", "内株", "7974", "JP", "JPY", "F00001", "ファンド1", "null", "B", "3000", "null", "null", "null", "10000", "東京", "20200206", "null");
            dt.Rows.Add("スライス用", "null", "■", "発注完了", "済", "57033000003", "null", "E000000000000001", "案件1", "P000000000000001", "B001", "ブローカー1", "内株", "1301", "JP", "JPY", "F00001", "ファンド1", "null", "B", "50000", "null", "null", "null", "10000", "東京", "20200206", "null");
            dt.Rows.Add("スライス用", "null", "■", "発注完了", "済", "95055000005", "null", "E000000000000001", "案件2", "P000000000000002", "B002", "ブローカー2", "内株", "3222", "JP", "JPY", "F00002", "ファンド2", "null", "S", "2000", "null", "null", "null", "10000", "東京", "20200206", "null");
            dt.Rows.Add("スライス用", "null", "■", "発注完了", "済", "1140660000", "null", "E000000000000001", "案件2", "P000000000000002", "B002", "ブローカー2", "内株", "3222", "JP", "JPY", "F00002", "ファンド2", "null", "S", "2000", "null", "null", "null", "10000", "東京", "20200206", "null");
            dt.Rows.Add("スライス用", "null", "■", "指示済み", "済", "1140660000", "null", "E000000000000001", "案件2", "P000000000000002", "B002", "ブローカー2", "内株", "3222", "JP", "JPY", "F00002", "ファンド2", "null", "S", "2000", "null", "null", "null", "10000", "東京", "20200206", "null");



            Type type = myDataGridView1.GetType();
            PropertyInfo pi = type.GetProperty("DoubleBuffered", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            pi.SetValue(myDataGridView1, true, null);

            return dt;
        }


        private DataTable GetTemporaryTable()
        {
            DataTable dt = new DataTable();
            for (int i = 1; i < 45; i++)
            {
                dt.Columns.Add("Column" + i, typeof(String));
            }
            return dt;
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (textBox1.Text == "")
                {
                    DataTable dt = GetTargetDatas();
                    FillDataGridViewWithDataSource(this.myDataGridView1, dt);
                }
                else
                {

                    string searchValue = textBox1.Text;
                    DataTable dt = GetTargetDatas();
                    DataTable dtTemporary = GetTemporaryTable();


                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        for (int j = 1; j < dt.Columns.Count; j++)
                        {

                            //if (dt.Rows[i]["Column" + j].ToString().Equals(searchValue))
                            if (dt.Rows[i]["Column" + j].ToString().IndexOf(searchValue, StringComparison.OrdinalIgnoreCase) >= 0) //fuzzy search
                            {
                                // MessageBox.Show(i + "" + "+" + j+"="+dt.Rows[i]["Column" + j].ToString());
                                dtTemporary.Rows.Add(dt.Rows[i].ItemArray);

                                break;
                            }

                        }
                    }


                    FillDataGridViewWithDataSource(this.myDataGridView1, dtTemporary);
                }
            }


        }
    }


}

