using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private BindingSource bindingSource1 = new BindingSource();
        private DeserializeDockContent m_deserializeDockContent;

        public Form1()
        {
            InitializeComponent();
            m_deserializeDockContent = new DeserializeDockContent(GetContentFromPersistString);
            this.Load += new EventHandler(Form1_Load);
        }

        private DummyTable1 CreateNewTable1(string text)
        {
            DummyTable1 dummyTable1 = new DummyTable1();
            dummyTable1.Text = text;
            return dummyTable1;
        }

        private DummyTable2 CreateNewTable2(string text)
        {
            DummyTable2 dummyTable2 = new DummyTable2();
            dummyTable2.Text = text;
            return dummyTable2;
        }
        private DummyTable3 CreateNewTable3(string text)
        {
            DummyTable3 dummyTable3 = new DummyTable3();
            dummyTable3.Text = text;
            return dummyTable3;
        }
        private DummyTable4 CreateNewTable4(string text)
        {
            DummyTable4 dummyTable4 = new DummyTable4();
            dummyTable4.Text = text;
            return dummyTable4;
        }
        private DummyTable5 CreateNewTable5(string text)
        {
            DummyTable5 dummyTable5 = new DummyTable5();
            dummyTable5.Text = text;
            return dummyTable5;
        }
        private DummyTable6 CreateNewTable6(string text)
        {
            DummyTable6 dummyTable6 = new DummyTable6();
            dummyTable6.Text = text;
            return dummyTable6;
        }
        private DummyTable7 CreateNewTable7(string text)
        {
            DummyTable7 dummyTable7 = new DummyTable7();
            dummyTable7.Text = text;
            return dummyTable7;
        }
        private DummyTable8 CreateNewTable8(string text)
        {
            DummyTable8 dummyTable8 = new DummyTable8();
            dummyTable8.Text = text;
            return dummyTable8;
        }
        private DummyTable9 CreateNewTable9(string text)
        {
            DummyTable9 dummyTable9 = new DummyTable9();
            dummyTable9.Text = text;
            return dummyTable9;
        }

        private IDockContent GetContentFromPersistString(string persistString)
        {

            if (persistString == typeof(DummyTable1).ToString()) {
                return CreateNewTable1("サマリー");
            } else if (persistString == typeof(DummyTable2).ToString())
            {
                return CreateNewTable2(" FMステータス");

            } else if (persistString == typeof(DummyTable3).ToString()) {
                return CreateNewTable3("リスト");
            }
            else if (persistString == typeof(DummyTable4).ToString())
            {
                return CreateNewTable4("警告");
            }
            else if (persistString == typeof(DummyTable5).ToString())
            {
                return CreateNewTable5("発注");
            }
            else if (persistString == typeof(DummyTable6).ToString())
            {
                return CreateNewTable6("6");
            }
            else if (persistString == typeof(DummyTable7).ToString())
            {
                return CreateNewTable7("未受領");
            }
            else if (persistString == typeof(DummyTable8).ToString())
            {
                return CreateNewTable8("発注済");
            }
            else if (persistString == typeof(DummyTable9).ToString())
            {
                return CreateNewTable9("出来");
            }

            return null;

        }


        private void Form1_Load(object sender, EventArgs e)
        {
            string configFile = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "DockPanel.temp.config");


            if (File.Exists(configFile))
            {
                dockPanel1.LoadFromXml(configFile, m_deserializeDockContent);
                dockPanel1.SuspendLayout(true);
            }
            else
            {
                dockPanel1.SuspendLayout(true);


                CloseAllDocuments();
                DummyTable1 doc1 = CreateNewTable1("Table1");
                DummyTable2 doc2 = CreateNewTable2("Table2");
                DummyTable3 doc3 = CreateNewTable3("Table3");
                DummyTable4 doc4 = CreateNewTable4("Table4");
                DummyTable5 doc5 = CreateNewTable5("Table5");
                DummyTable6 doc6 = CreateNewTable6("Table6");
                DummyTable7 doc7 = CreateNewTable7("Table7");
                DummyTable8 doc8 = CreateNewTable8("Table8");
                DummyTable9 doc9 = CreateNewTable9("Table9");
                doc1.Show(dockPanel1, DockState.Document);
                doc3.Show(doc1.Pane, DockAlignment.Bottom, 0.5);
                doc4.Show(doc3.Pane, DockAlignment.Left, 0.5);
                doc2.Show(doc4.Pane, DockAlignment.Right, 0.5);
                doc5.Show(doc2.Pane, DockAlignment.Right, 0.5);
                doc6.Show(doc2.Pane, DockAlignment.Right, 0.5);
                doc7.Show(doc2.Pane, DockAlignment.Right, 0.5);
                doc8.Show(doc2.Pane, DockAlignment.Right, 0.5);
                doc9.Show(doc2.Pane, DockAlignment.Right, 0.5);
            }

            dockPanel1.ResumeLayout(true, true);


        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = "D:\\";
            openFileDialog.Filter = "txt files (*.txt,*.*)|*.txt;*.*";
            openFileDialog.FilterIndex = 1;
            openFileDialog.RestoreDirectory = true;
            openFileDialog.Title = "Open";
            openFileDialog.ShowDialog();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            string configFile = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "DockPanel.temp.config");

            dockPanel1.SaveAsXml(configFile);
        }

        private void whiteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string configFile = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "DockPanel.temp.config");

            dockPanel1.SaveAsXml(configFile);

            CloseAllContents();

            this.dockPanel1.Theme = this.vS2015LightTheme1;


            if (File.Exists(configFile))
                dockPanel1.LoadFromXml(configFile, m_deserializeDockContent);
        }


        private void CloseAllContents()
        {

            // Close all other document windows
            CloseAllDocuments();

            // IMPORTANT: dispose all float windows.
            foreach (var window in dockPanel1.FloatWindows.ToList())
                window.Dispose();

            System.Diagnostics.Debug.Assert(dockPanel1.Panes.Count == 0);
            System.Diagnostics.Debug.Assert(dockPanel1.Contents.Count == 0);
            System.Diagnostics.Debug.Assert(dockPanel1.FloatWindows.Count == 0);
        }

        private void CloseAllDocuments()
        {
            if (dockPanel1.DocumentStyle == DocumentStyle.SystemMdi)
            {
                foreach (Form form in MdiChildren)
                    form.Close();
            }
            else
            {
                foreach (IDockContent document in dockPanel1.DocumentsToArray())
                {
                    // IMPORANT: dispose all panes.
                    document.DockHandler.DockPanel = null;
                    document.DockHandler.Close();
                }
            }
        }

        /*private void blackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string configFile = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "DockPanel.temp.config");

            dockPanel1.SaveAsXml(configFile);

            CloseAllContents();

            this.dockPanel1.Theme = this.vS2015DarkTheme1;


            if (File.Exists(configFile))
                dockPanel1.LoadFromXml(configFile, m_deserializeDockContent);
        }*/
    }
}
