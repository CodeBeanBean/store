using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace MyDataGridView
{
    public partial class MyDataGridView : DataGridView
    {
        public MyDataGridView()
        {
        }

        int rowFlag = 0;
        int rowIndex = 0;
        int columnIndex = 0;
        List<int> _columns = new List<int>();
        List<int> _rows = new List<int>();

        protected override void OnCreateControl()
        {
            this.AllowUserToAddRows = false;
            this.AllowUserToDeleteRows = false;
            this.AllowUserToOrderColumns = true;
            //this.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            //this.Dock = System.Windows.Forms.DockStyle.Fill;
            //this.Location = new System.Drawing.Point(0, 4);
            this.ReadOnly = true;
            this.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.TabIndex = 0;
            base.OnCreateControl();
        }

        /*        protected override void OnCellMouseClick(DataGridViewCellMouseEventArgs e)
                {
                    if (e.ColumnIndex >= 0 && e.RowIndex >= 0)
                    {
                        rowFlag = 1;
                        this.CurrentCell = this.Rows[e.RowIndex].Cells[e.ColumnIndex];
                        this.Rows[e.RowIndex].Selected = true;
                        this.Refresh();
                        base.OnCellMouseClick(e);
                    }

                }*/

        /*        protected override void OnColumnHeaderMouseClick(DataGridViewCellMouseEventArgs e)
                {
                    if (e.Button == MouseButtons.Left) {
                        rowFlag = 2;
                        this.CurrentCell = this.Rows[0].Cells[e.ColumnIndex];
                        //this.Rows[0].Selected = false;
                        this.Refresh();
                        base.OnColumnHeaderMouseClick(e);
                    }
                }

                protected override void OnRowHeaderMouseClick(DataGridViewCellMouseEventArgs e)
                {
                    if (e.Button == MouseButtons.Left)
                    {
                        rowFlag = 1;
                        rowIndex = e.RowIndex;
                        columnIndex = 0;
                        this.CurrentCell = this.Rows[e.RowIndex].Cells[0];
                        //this.Rows[0].Selected = false;
                        base.OnRowHeaderMouseClick(e);
                        this.Refresh();
                    }
                }*/

        protected override void OnCellMouseDown(DataGridViewCellMouseEventArgs e)
        {           
            if (e.Button == MouseButtons.Left)
            {
                if (e.ColumnIndex >= 0 && e.RowIndex >= 0)
                {
                    this.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    base.OnCellMouseDown(e);
                    rowFlag = 1;                   
                    columnIndex = e.ColumnIndex;
                    _columns.Clear();                  
                    if (this.Rows[e.RowIndex].Selected)
                    {
                        rowIndex = e.RowIndex;
                    }
                }
                else if (e.ColumnIndex < 0 && e.RowIndex >= 0)
                {
                    this.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    base.OnCellMouseDown(e);
                    rowFlag = 1;
                    if (this.Rows[e.RowIndex].Selected)
                    {
                        rowIndex = e.RowIndex;
                    }
                    columnIndex = 0;
                    _columns.Clear();
                }
                else if (e.ColumnIndex >= 0 && e.RowIndex < 0)
                {
                    rowFlag = 2;
                    rowIndex = 0;
                    // Control key down
                    if ((ModifierKeys & Keys.Control) == Keys.Control)
                    {
                        if (_columns.Contains(e.ColumnIndex))
                        {
                            _columns.Remove(e.ColumnIndex);
                            //yellow change
                            if (columnIndex == e.ColumnIndex && _columns.Count >= 1)
                            {
                                for (int i = columnIndex; i >= 0; i--)
                                {
                                    if (_columns.Contains(i))
                                    {
                                        columnIndex = i;
                                        break;
                                    }
                                }
                                if (columnIndex == e.ColumnIndex)
                                {
                                    for (int i = columnIndex; i <= this.Columns.Count; i++)
                                    {
                                        if (_columns.Contains(i))
                                        {
                                            columnIndex = i;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (_columns.Count == 0)
                            {
                                columnIndex = e.ColumnIndex;
                            }
                            _columns.Add(e.ColumnIndex);
                        }
                    } else if ((ModifierKeys & Keys.Shift) == Keys.Shift) {
                        if (_columns.Count >= 1)
                        {
                            _columns.Clear();
                            if (columnIndex >= e.ColumnIndex)
                            {
                                for (int i = e.ColumnIndex; i <= columnIndex; i++)
                                {
                                    _columns.Add(i);
                                }
                            }
                            else
                            {
                                for (int i = columnIndex; i <= e.ColumnIndex; i++)
                                {
                                    _columns.Add(i);
                                }
                            }
                        }
                        else {
                                columnIndex = e.ColumnIndex;
                                _columns.Add(e.ColumnIndex);
                        }
                    }
                    else
                    {
                        columnIndex = e.ColumnIndex;
                        _columns.Clear();
                        _columns.Add(e.ColumnIndex);
                    }
                    this.SelectionMode = DataGridViewSelectionMode.CellSelect;
                    base.OnCellMouseDown(e);
                    //this.Columns[e.ColumnIndex].Selected = true;
                    //this.MultiSelect = false;
                    //rowFlag = 2;
                    //columnIndex = e.ColumnIndex;
                    //_columns.Add(e.ColumnIndex);
                    //this.CurrentCell = this.Rows[0].Cells[e.ColumnIndex];
                    _rows.Clear();
                }
                else
                {
                    this.SelectionMode = DataGridViewSelectionMode.CellSelect;
                    base.OnCellMouseDown(e);
                    rowFlag = 1;
                    rowIndex = 0;
                    columnIndex = 0;
                    _columns.Clear();
                }
                // this.Refresh();

            }            
            this.Refresh();
        }
        /*        void Control_MouseMove(object sender, MouseEventArgs e)
                {
                    if (e.Button == MouseButtons.Left)
                    {
                        //this.Rows[e.RowIndex].Selected = true;
                        //e.
                        this.CurrentCell = this.Rows[rowIndex].Cells[columnIndex];
                    }
                }*/
        /*        protected override void OnCellMouseMove(DataGridViewCellMouseEventArgs e)
                {
                    if ((e.Clicks < 2) && (e.Button == MouseButtons.Left))
                    {
                        if ((e.ColumnIndex == -1) && (e.RowIndex > -1))
                            this.DoDragDrop(this.Rows[e.RowIndex], DragDropEffects.None);
                    }
                }*/


        /*        //获取行坐标
                private int GetRowFromPoint(int x, int y)
                {
                    for (int i = 0; i < this.RowCount; i++)
                    {
                        Rectangle rec = this.GetRowDisplayRectangle(i, false);

                        if (this.RectangleToScreen(rec).Contains(x, y))
                            return i;
                    }

                    return -1;
                }*/

        protected override void OnCellPainting(DataGridViewCellPaintingEventArgs e)
        {
            if (rowFlag == 1)
            {


                if (e.RowIndex >= 0
                /*&& e.ColumnIndex >= 0 && e.RowIndex == _rows[i])*/
                && e.ColumnIndex >= 0 && this.Rows[e.RowIndex].Cells[e.ColumnIndex].Selected)
                {
                        Rectangle newRect = new Rectangle(e.CellBounds.X + 1,
                            e.CellBounds.Y + 1, e.CellBounds.Width - 4,
                            e.CellBounds.Height - 4);

                        using (
                            Brush gridBrush = new SolidBrush(this.GridColor),
                            backColorBrush = new SolidBrush(Color.FromArgb(250, 250, 250)))
                        {
                            using (Pen gridLinePen = new Pen(gridBrush))
                            {
                                // Erase the cell.
                                e.Graphics.FillRectangle(backColorBrush, e.CellBounds);

                                // Draw the grid lines (only the right and bottom lines;
                                // DataGridView takes care of the others).
                                e.Graphics.DrawLine(gridLinePen, e.CellBounds.Left,
                                    e.CellBounds.Bottom - 1, e.CellBounds.Right - 1,
                                    e.CellBounds.Bottom - 1);
                                e.Graphics.DrawLine(gridLinePen, e.CellBounds.Right - 1,
                                    e.CellBounds.Top, e.CellBounds.Right - 1,
                                    e.CellBounds.Bottom);

                                // Draw border
                                if (e.ColumnIndex >= 0 && e.ColumnIndex == columnIndex && e.RowIndex == rowIndex)
                                {
                                    Pen pen = new Pen(Color.FromArgb(255, 255, 0))
                                    {
                                        DashStyle = DashStyle.Dash
                                    };
                                    e.Graphics.DrawRectangle(pen, newRect);
                                }
                                else
                                {
                                    e.Graphics.DrawRectangle(Pens.Blue, newRect);
                                }

                                // Draw the text content of the cell, ignoring alignment.
                                if (e.Value != null)
                                {
                                    e.Graphics.DrawString((String)e.Value, e.CellStyle.Font,
                                        Brushes.Black, e.CellBounds.X + 2,
                                        e.CellBounds.Y + 2, StringFormat.GenericDefault);
                                }
                                /*if (e.Value == null)
                                {

                                }
                            e.Handled = true;
                           */
                          
                             }
                        }
                    }
                }

            else if (rowFlag == 2)
            {
                for (int i = 0; i < _columns.Count; i++)
                {
                    if (e.ColumnIndex >= 0 && e.RowIndex >= 0
                    /*&& this.Columns[e.ColumnIndex].Selected)*/
                    && e.ColumnIndex == _columns[i])
                    {
                        Rectangle newRect = new Rectangle(e.CellBounds.X + 1,
                            e.CellBounds.Y + 1, e.CellBounds.Width - 4,
                            e.CellBounds.Height - 4);

                        using (
                            Brush gridBrush = new SolidBrush(this.GridColor),
                            backColorBrush = new SolidBrush(Color.FromArgb(250, 250, 250)))
                        {
                            using (Pen gridLinePen = new Pen(gridBrush))
                            {
                                // Erase the cell.
                                e.Graphics.FillRectangle(backColorBrush, e.CellBounds);

                                // Draw the grid lines (only the right and bottom lines;
                                // DataGridView takes care of the others).
                                e.Graphics.DrawLine(gridLinePen, e.CellBounds.Left,
                                    e.CellBounds.Bottom - 1, e.CellBounds.Right - 1,
                                    e.CellBounds.Bottom - 1);
                                e.Graphics.DrawLine(gridLinePen, e.CellBounds.Right - 1,
                                    e.CellBounds.Top, e.CellBounds.Right - 1,
                                    e.CellBounds.Bottom);

                                // Draw the inset highlight box.
                                if (e.ColumnIndex >= 0 && e.RowIndex == 0 && e.ColumnIndex == columnIndex)
                                {
                                    Pen pen = new Pen(Color.FromArgb(255, 255, 0))
                                    {
                                        DashStyle = DashStyle.Dot
                                    };
                                    e.Graphics.DrawRectangle(pen, newRect);
                                }
                                else
                                {
                                    e.Graphics.DrawRectangle(Pens.Blue, newRect);
                                }

                                // Draw the text content of the cell, ignoring alignment.
                                if (e.Value != null)
                                {
                                    e.Graphics.DrawString((String)e.Value, e.CellStyle.Font,
                                        Brushes.Black, e.CellBounds.X + 2,
                                        e.CellBounds.Y + 2, StringFormat.GenericDefault);
                                }
                                e.Handled = true;
                            }
                        }
                    }
                }
            }
        }
    }
}
