// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 

package chart;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JPanel;
import org.jfree.chart.*;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.StandardBarPainter;
import org.jfree.chart.renderer.xy.StandardXYBarPainter;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.gantt.*;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;

import util.ChartUtils;
import util.MyGanttRenderer;
import util.MyTask;

public class MyGanntTest extends ApplicationFrame
{

	public MyGanntTest(String s)
	{
		super(s);
		JPanel jpanel = createDemoPanel();
		jpanel.setPreferredSize(new Dimension(500, 270));
		setContentPane(jpanel);
	}

	/**
	 * @param intervalcategorydataset
	 * @return
	 */
	private static JFreeChart createChart(IntervalCategoryDataset intervalcategorydataset)
	{
		Font FONT = new Font("����", Font.PLAIN, 12);
		StandardChartTheme chartTheme = new StandardChartTheme("CN");
		chartTheme.setExtraLargeFont(FONT);
		// ����ͼ��������
		chartTheme.setRegularFont(FONT);
		// �������������
		chartTheme.setLargeFont(FONT);
		chartTheme.setSmallFont(FONT);
		ChartFactory.setChartTheme(chartTheme);
		
		JFreeChart jfreechart = ChartFactory.createGanttChart("Gantt Chart Demo", "Task", "Date", intervalcategorydataset, true, true, false);
		jfreechart.setTitle("");//����Ϊ��
		CategoryPlot categoryplot = (CategoryPlot)jfreechart.getPlot();
		
		
		DateAxis axis = (DateAxis) categoryplot.getRangeAxis();
		axis.setVisible(true);
		//axis.setDateFormatOverride();
		axis.setLabel(null);//x����ⲻ��ʾ
		
		
		categoryplot.getDomainAxis().setVisible(false);//��߷����᲻��ʾ
		categoryplot.getDomainAxis().setMaximumCategoryLabelWidthRatio(10F);
	//	CategoryItemRenderer categoryitemrenderer = categoryplot.getRenderer();
	//	categoryitemrenderer.setSeriesPaint(0, Color.blue);
		
		
	//	categoryplot.getRangeAxis().setTickMarkPaint(Color.decode("#B0C4DE"));
		categoryplot.setRangeGridlinePaint(Color.decode("#B0C4DE"));//��ֱ����ɫ
		categoryplot.setRangeGridlineStroke(new BasicStroke(0.5f));//��ֱ���� ��ϸ
		categoryplot.setRangeGridlinesVisible(true);//��ֱ����ʾ
		
		
		categoryplot.setBackgroundPaint(Color.decode("#EEE0E5"));//����ɫ
		MyGanttRenderer renderer = new MyGanttRenderer();
		categoryplot.setRenderer(renderer);
//		
		 renderer.setBaseItemLabelGenerator(new CategoryItemLabelGenerator() {

		      public String generateLabel(CategoryDataset dataset, int series, int categories) {
		       /* your code to get the label */
		    	  // System.out.println(dataset.toString());
		          //return String.valueOf(categories);
		        //  return dataset.getRowKey(series).toString();
		    	  return dataset.getColumnKey(categories).toString();

		      }

		      public String generateColumnLabel(CategoryDataset dataset, int categories) {
		         // return dataset.getColumnKey(categories).toString();
		    	  return null;
		      }

		      public String generateRowLabel(CategoryDataset dataset, int series) {
		         // return dataset.getRowKey(series).toString();
		    	  return null;
		      }
		 });
		 renderer.setBarPainter(new StandardBarPainter());
		 renderer.setBaseItemLabelsVisible(true); //��ǩ��ʾ
		 renderer.setBaseItemLabelPaint(Color.decode("#095cae"));
		 renderer.setBasePositiveItemLabelPosition(new ItemLabelPosition(ItemLabelAnchor.OUTSIDE6, TextAnchor.BOTTOM_CENTER));//���ֱ�ǩλ��
		 renderer.setSeriesPaint(0, Color.decode("#B0C4DE")); //series1 ��ɫ
		 renderer.setSeriesPaint(1, Color.decode("#e8abab")); //serise2��ɫ
		 
		 renderer.setSeriesItemLabelsVisible(2, false);
		 
/*		 renderer.setAutoPopulateSeriesFillPaint(false);
		 renderer.setAutoPopulateSeriesPaint(false);
		 renderer.setGradientPaintTransformer(null);
		 renderer.setSeriesOutlinePaint(0,null );
		 renderer.setSeriesOutlinePaint(3,null );*/
		 renderer.setShadowVisible(false); //�ر�bar�ĵ���Ӱ
		
		 renderer.setItemMargin(-0.5f);;//bar����߾�
		// renderer.setMinimumBarLength(1.0f);; ��Сbar���Ȳ���Ч
		 renderer.setBaseSeriesVisibleInLegend(false);//�ײ�ϵ�б�ǩ����ʾ
		 
		 return jfreechart;
		 
	}

	private static IntervalCategoryDataset createDataset()
	{
	
		
		TaskSeries taskseries3 = new TaskSeries("income");
		Task task = new Task("Write Proposal", date(1, 1, 2020), date(12, 12, 2080));
		Task task17 = new Task("Write Proposal 1", date(1, 1, 2020), date(5,5, 2045));
		Task task18 = new Task("Write Proposal 2", date(30, 5, 2050), date(6, 12, 2080));
		task.addSubtask(task17);
		task.addSubtask(task18);
		Task task19 = new Task("Obtain Approval", date(9, 3, 2042), date(9, 4, 2055));
		taskseries3.add(task);
		taskseries3.add(task19);
		
		
		TaskSeries taskseries2 = new TaskSeries("consume");
		Task task1 = new Task("Write Proposal23123", date(1,1, 2020), date(5, 12, 2080));
		taskseries2.add(task1);

		Task task2 = new Task("Requirements", date(10, 3, 2020), date(5, 10, 2080));
		Task task3 = new Task("Requirements 1", date(10, 2, 2020), date(20, 3, 2035));
		Task task4 = new Task("Requirements 2", date(1, 4, 2039), date(5, 6, 2055));
		task2.addSubtask(task3);
		task2.addSubtask(task4);
		taskseries2.add(task2);
		
		MyTask task21  =  new MyTask("21", date(1, 1, 2040), date(1, 12, 2040));
		taskseries2.add(task21);
		
		Task task9 = new Task("Design Signoff", date(2, 5, 2045), date(2, 5, 2060));
		taskseries2.add(task9);
		Task task10 = new Task("Alpha Implementation", date(3, 5, 2045), date(31, 6, 2060));
		taskseries2.add(task10);
		Task task11 = new Task("Design Review", date(1, 1, 2050), date(1, 12, 2050));
		taskseries2.add(task11);
		Task task13 = new Task("Beta Implementation", date(12, 7, 2020), date(12, 8, 2049));
		taskseries2.add(task13);
		Task task14 = new Task("Testing", date(13, 8, 2050), date(31, 9, 2059));
		taskseries2.add(task14);
		Task task15 = new Task("Final Implementation", date(1, 10, 2048), date(15, 10, 2080));
		taskseries2.add(task15);
		Task task16 = new Task("Signoff", date(28, 10, 2058), date(30, 10, 2080));
		taskseries2.add(task16);
		Task task111 = new Task("Signoff2", date(28, 10, 2075), date(30, 10, 2080));
		taskseries2.add(task111);

		
		TaskSeriesCollection taskseriescollection = new TaskSeriesCollection();
		
		taskseriescollection.add(taskseries3);
		taskseriescollection.add(taskseries2);
	

		
	TaskSeries taskseries4 = new TaskSeries("BBBB");
		Task task44 = new Task("fill1", date(1, 3, 2020), date(1, 3, 2020));
		Task task45 = new Task("fill2", date(1, 3, 2020), date(1, 3, 2020));
		Task task46 = new Task("fill3", date(1, 3, 2020), date(1, 3, 2020));
		taskseries4.add(task44);
		taskseries4.add(task45);
		taskseries4.add(task46);
		taskseriescollection.add(taskseries4);
		
	/*	TaskSeries taskseries5 = new TaskSeries("AAAA");
		Task task55 = new Task("", date(1, 3, 2020), date(1, 3, 2050));
		taskseries5.add(task55);
		taskseriescollection.add(taskseries5);*/
	
		return taskseriescollection;
	}

	private static Date date(int i, int j, int k)
	{
		Calendar calendar = Calendar.getInstance();
		calendar.set(k, j, i);
		Date date1 = calendar.getTime();
		return date1;
	}
	

	public static JPanel createDemoPanel()
	{
		JFreeChart jfreechart = createChart(createDataset());
		//jfreechart.setBackgroundPaint(Color.decode("#EEE0E5"));//set backgroud color
		ChartPanel chartpanel = new ChartPanel(jfreechart);
		chartpanel.setMouseWheelEnabled(true);
		return chartpanel;
	}

	public static void main(String args[])
	{
		
		
		MyGanntTest ganttdemo2 = new MyGanntTest("JFreeChart: GanttDemo2.java");
		ganttdemo2.pack();
		RefineryUtilities.centerFrameOnScreen(ganttdemo2);
		ganttdemo2.setVisible(true);
	}
}
