package util;

import java.util.Date;

import org.jfree.data.gantt.Task;

public class MyTask extends Task{

	
    /** The task description. */
    private String description;
    
	public MyTask(String description, Date start, Date end) {
		super(description, start, end);
		// TODO Auto-generated constructor stub
		this.description =description;
	}

	@Override
	public String toString() {
		return " [description=" + description + "]";
	}
	
	

}
