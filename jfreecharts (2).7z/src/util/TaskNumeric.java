package util;

import java.util.Date;

import org.jfree.data.gantt.Task;

public class TaskNumeric extends Task {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TaskNumeric(String description, long start, long end) {
        super(description, new Date(start), new Date(end));
    }

    public static TaskNumeric duration(String description, long start, long duration) {
        return new TaskNumeric(description, start, start + duration);
    }

}