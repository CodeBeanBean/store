package chart;


import java.awt.Color;
import java.awt.Paint;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.GanttRenderer;
import org.jfree.chart.renderer.category.StandardBarPainter;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.gantt.Task;
import org.jfree.data.gantt.TaskSeries;
import org.jfree.data.gantt.TaskSeriesCollection;
import org.jfree.data.time.SimpleTimePeriod;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class GanttDemo7 extends ApplicationFrame {

    private static final long serialVersionUID = 1L;
    public static final TaskSeriesCollection model = new TaskSeriesCollection();

    public GanttDemo7(final String title) {
        super(title);
        final IntervalCategoryDataset dataset = createSampleDataset();
        // create the chart...
        final JFreeChart chart = ChartFactory.createGanttChart(
                "Diagramme de Gantt", // chart title
                "Processus", // domain axis label
                "temps(ms)", // range axis label
                dataset, // data
                false, // include legend
                true, // tooltips
                false // urls
        );
        final CategoryPlot plot = (CategoryPlot) chart.getPlot();
        DateAxis range = (DateAxis) plot.getRangeAxis();
        range.setDateFormatOverride(new SimpleDateFormat("SSS"));
        range.setMaximumDate(new Date(100));

        // add the chart to a panel...
        final ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(500, 270));
        setContentPane(chartPanel);

        //GanttRenderer personnalisÃ©..
        MyRenderer renderer = new MyRenderer(model);
        
        renderer.setBaseItemLabelGenerator(new CategoryItemLabelGenerator() {

		      public String generateLabel(CategoryDataset model, int series, int categories) {
		    
		    	  return model.getColumnKey(categories).toString() ;
		      }

		      public String generateColumnLabel(CategoryDataset dataset, int categories) {
		         // return dataset.getColumnKey(categories).toString();
		    	  return null;
		      }

		      public String generateRowLabel(CategoryDataset dataset, int series) {
		         // return dataset.getRowKey(series).toString();
		    	  return null;
		      }
		 });
        renderer.setBarPainter(new StandardBarPainter());
        renderer.setBaseItemLabelsVisible(true); //标签显示
        plot.setRenderer(renderer);
        plot.setBackgroundPaint(Color.WHITE);
        

    }

   
    
    private static class MyRenderer extends GanttRenderer {

        private static final int PASS = 2; // assumes two passes
        private final List<Color> clut = new ArrayList<>();
        private final TaskSeriesCollection model;
        private int row;
        private int col;
        private int index;

        public MyRenderer(TaskSeriesCollection model) {
            this.model = model;
        }


        
        @Override
        public Paint getItemPaint(int row, int col) {

            if (clut.isEmpty() || this.row != row || this.col != col) {
                initClut(row, col);
                this.row = row;
                this.col = col;
                index = 0;
            }
            int clutIndex = index++ / PASS;
            return clut.get(clutIndex);
        }

        private void initClut(int row, int col) {
            clut.clear();

            TaskSeries series = (TaskSeries) model.getRowKeys().get(row);
            List<Task> tasks = series.getTasks(); // unchecked 

            int taskCount = tasks.get(col).getSubtaskCount();
            taskCount = Math.max(1, taskCount);

            System.out.println("----> " + taskCount);
            String description;

            for (int i = 0; i < taskCount; i++) {
                description = tasks.get(col).getSubtask(i).getDescription();

                System.out.println(description + ": " + i);
                if (description.equals("bloque")) {
                    clut.add(Color.green);
                    System.out.println("green");
                }
                if (description.equals("ES")) {
                    clut.add(Color.yellow);
                    System.out.println("yellow");
                }
                if (description.equals("exec")) {
                    clut.add(Color.blue);
                    System.out.println("blue");
                }
            }
        }
    }

    private IntervalCategoryDataset createSampleDataset() {
        final TaskSeries s1 = new TaskSeries("");
        final Task t0 = new Task("P0", new SimpleTimePeriod(30, 50));
        final Task st0 = new Task("exec", new SimpleTimePeriod(10, 20));
        // Task st01 = new Task( "ES",new SimpleTimePeriod(30,60));
        t0.addSubtask(st0);
        //   t.addSubtask(st01);
        s1.add(t0);

        final Task t1 = new Task("P1", new SimpleTimePeriod(5, 10));
        final Task st11 = new Task("ES", new SimpleTimePeriod(10, 20));
        Task st12 = new Task("exec", new SimpleTimePeriod(30, 60));
        t1.addSubtask(st11);
        t1.addSubtask(st12);
        s1.add(t1);

        final Task t2 = new Task("P2", new SimpleTimePeriod(0, 40));
        final Task st31 = new Task("bloque", new SimpleTimePeriod(5, 30));
        final Task st32 = new Task("exec", new SimpleTimePeriod(50, 60));
        t2.addSubtask(st31);
        t2.addSubtask(st32);
        s1.add(t2);

/*        final TaskSeries s2 = new TaskSeries("b");
        final Task t4 = new Task("P0", new SimpleTimePeriod(30, 50));
        final Task st4 = new Task("exec", new SimpleTimePeriod(10, 20));
        // Task st01 = new Task( "ES",new SimpleTimePeriod(30,60));
        t4.addSubtask(st4);
        //   t.addSubtask(st01);
        s2.add(t4);
        
        final Task t5 = new Task("P1", new SimpleTimePeriod(5, 10));
        final Task st51 = new Task("ES", new SimpleTimePeriod(10, 20));
        Task st52 = new Task("exec", new SimpleTimePeriod(30, 60));
        t5.addSubtask(st51);
        t5.addSubtask(st52);
        s2.add(t5);
        model.add(s2);
        */
        
        model.add(s1);
      
        return model;
    }

    public static void main(final String[] args) {
        final GanttDemo7 demo = new GanttDemo7("Gantt Chart Demo 7");
        demo.pack();
        RefineryUtilities.centerFrameOnScreen(demo);
        demo.setVisible(true);
    }
}