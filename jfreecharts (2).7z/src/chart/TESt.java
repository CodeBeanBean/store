package chart;

import java.awt.Paint;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.DefaultDrawingSupplier;
import org.jfree.chart.renderer.category.GanttRenderer;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.gantt.Task;
import org.jfree.data.gantt.TaskSeries;
import org.jfree.data.gantt.TaskSeriesCollection;
import org.jfree.data.time.SimpleTimePeriod;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class TESt extends ApplicationFrame {


    public TESt(String title) {
        super(title);
        JPanel chartPanel = createDemoPanel();
        chartPanel.setPreferredSize(new java.awt.Dimension(500, 270));
        setContentPane(chartPanel);
    }

    /**
     * Creates a sample dataset for a Gantt chart.
     *
     * @return The dataset.
     */
    public static IntervalCategoryDataset createDataset() {

        TaskSeries s1 = new TaskSeries("1");
        s1.add(new Task("Contrakt 1", new SimpleTimePeriod(date(1, Calendar.JANUARY, 2005), date(31, Calendar.JUNE, 2005))));
        TaskSeries s2 = new TaskSeries("2");
        s2.add(new Task("Contrakt 1", new SimpleTimePeriod(date(1, Calendar.JULY, 2005), date(1, Calendar.FEBRUARY, 2006))));
        TaskSeries s3 = new TaskSeries("3");
        s3.add(new Task("Contrakt 2", new SimpleTimePeriod(date(1, Calendar.JANUARY, 2005), date(1, Calendar.FEBRUARY, 2006))));
        TaskSeries s4 = new TaskSeries("4");
        s4.add(new Task("Contrakt 3", new SimpleTimePeriod(date(1, Calendar.JANUARY, 2005), date(1, Calendar.FEBRUARY, 2006))));

        TaskSeriesCollection collection = new TaskSeriesCollection();
        collection.add(s1);
        collection.add(s2);
        collection.add(s3);
        collection.add(s4);

        return collection;
    }

    /**
     * Utility method for creating <code>Date</code> objects.
     *
     * @param day  the date.
     * @param month  the month.
     * @param year  the year.
     *
     * @return a date.
     */
    private static Date date(int day, int month, int year) {

        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day);
        Date result = calendar.getTime();
        return result;

    }

    /**
     * Creates a chart.
     * 
     * @param dataset  the dataset.
     * 
     * @return The chart.
     */
    private static JFreeChart createChart(IntervalCategoryDataset dataset) {
        JFreeChart chart = ChartFactory.createGanttChart("Contract Version Validity Demo", // chart title
                "", // domain axis label
                null, // range axis label
                dataset, // data
                false, // include legend
                true, // tooltips
                false // urls
                );
        CategoryPlot plot = (CategoryPlot) chart.getPlot();
        MyGanttRenderer renderer = new MyGanttRenderer();
        plot.setRenderer(renderer);
        plot.getDomainAxis().setMaximumCategoryLabelWidthRatio(10.0f);
        renderer.setDrawBarOutline(false);
        return chart;
    }

    /**
     * Creates a panel for the demo (used by SuperDemo.java).
     * 
     * @return A panel.
     */
    public static JPanel createDemoPanel() {
        JFreeChart chart = createChart(createDataset());
        return new ChartPanel(chart);
    }

    /**
     * Starting point for the demonstration application.
     *
     * @param args  ignored.
     */
    public static void main(String[] args) {

        TESt demo = new TESt("Gantt Chart Demo 3");
        demo.pack();
        RefineryUtilities.centerFrameOnScreen(demo);
        demo.setVisible(true);

    }

    static class MyGanttRenderer extends GanttRenderer {

        public MyGanttRenderer() {
            super();
        }

        public Paint getItemPaint(int row, int column) {
            return DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE[column];
        }
    }

}