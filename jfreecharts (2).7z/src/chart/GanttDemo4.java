package chart;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.util.List;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.StandardBarPainter;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.gantt.Task;
import org.jfree.data.gantt.TaskSeries;
import org.jfree.data.gantt.TaskSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;

import util.GanttChartFactory;
import util.MyGanttRenderer;
import util.TaskNumeric;

public class GanttDemo4 extends ApplicationFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 9024169507917888101L;
	public static final TaskSeriesCollection model = new TaskSeriesCollection();
	
	public GanttDemo4(String s) {
        super(s);
        JPanel jpanel = createDemoPanel();
        jpanel.setPreferredSize(new Dimension(500, 270));
        setContentPane(jpanel);
    }

	 private static JFreeChart createChart(IntervalCategoryDataset dataset) {
	        final JFreeChart chart = GanttChartFactory.createGanttChart(
	                "Gantt Chart Demo", "Task", "Value", dataset, true, true, false);
	        
			CategoryPlot categoryplot = (CategoryPlot)chart.getPlot();
			chart.setTitle("");//����Ϊ��
			
			
			ValueAxis axis =  categoryplot.getRangeAxis();
			axis.setVisible(true);
			axis.setLabel(null);//x����ⲻ��ʾ


			
			categoryplot.getDomainAxis().setVisible(false);//��߷����᲻��ʾ
			categoryplot.getDomainAxis().setMaximumCategoryLabelWidthRatio(10F);

		
			categoryplot.setRangeGridlinePaint(Color.decode("#B0C4DE"));//��ֱ����ɫ
			categoryplot.setRangeGridlineStroke(new BasicStroke(0.5f));//��ֱ���� ��ϸ
			categoryplot.setRangeGridlinesVisible(true);//��ֱ����ʾ
			
			
			categoryplot.setBackgroundPaint(Color.decode("#EEE0E5"));//����ɫ
			
			
			
			MyGanttRenderer renderer = new MyGanttRenderer();
			categoryplot.setRenderer(renderer);
			
			
			renderer.setBaseItemLabelGenerator(new CategoryItemLabelGenerator() {

			      public String generateLabel(CategoryDataset dataset, int series, int categories) {
			    
			    	  TaskSeries taskseries = (TaskSeries) model.getRowKeys().get(series);
			           @SuppressWarnings("unchecked")
					List<Task> tasks = taskseries.getTasks(); // unchecked 
			    	  
			           int taskCount = tasks.get(categories).getSubtaskCount();
			            taskCount = Math.max(1, taskCount);
			    	  
			            String description = null;
			            for (int i = 0; i < taskCount; i++) {
			                description = tasks.get(categories).getSubtask(i).getDescription();
			            }
						
			            
			    	  return description ;
			      }

			      public String generateColumnLabel(CategoryDataset dataset, int categories) {
			         // return dataset.getColumnKey(categories).toString();
			    	  return null;
			      }

			      public String generateRowLabel(CategoryDataset dataset, int series) {
			         // return dataset.getRowKey(series).toString();
			    	  return null;
			      }
			 });
			
			
			renderer.setBarPainter(new StandardBarPainter());
			 renderer.setBaseItemLabelsVisible(true); //��ǩ��ʾ
			 renderer.setBaseItemLabelPaint(Color.decode("#095cae"));
			 renderer.setBasePositiveItemLabelPosition(new ItemLabelPosition(ItemLabelAnchor.OUTSIDE6, TextAnchor.BOTTOM_CENTER));//���ֱ�ǩλ��
			 renderer.setSeriesPaint(0, Color.decode("#B0C4DE")); //series1 ��ɫ
			 renderer.setSeriesPaint(1, Color.decode("#e8abab")); //serise2��ɫ
			 
			 renderer.setSeriesItemLabelsVisible(2, false);
			 
	/*		 renderer.setAutoPopulateSeriesFillPaint(false);
			 renderer.setAutoPopulateSeriesPaint(false);
			 renderer.setGradientPaintTransformer(null);
			 renderer.setSeriesOutlinePaint(0,null );
			 renderer.setSeriesOutlinePaint(3,null );*/
			 renderer.setShadowVisible(false); //�ر�bar�ĵ���Ӱ
			
			 renderer.setItemMargin(-0.5f);;//bar����߾�
			// renderer.setMinimumBarLength(1.0f);; ��Сbar���Ȳ���Ч
			 renderer.setBaseSeriesVisibleInLegend(false);//�ײ�ϵ�б�ǩ����ʾ
			
	            return chart;
	    }
    private static IntervalCategoryDataset createDataset() {
    	
      //  Task task = new TaskNumeric("task1", 0, 5);
    	TaskSeries taskseries3 = new TaskSeries("income");
		Task task = new TaskNumeric("Write Proposal", 40, 100);
		Task task17 = new TaskNumeric("Write Proposal 1", 40, 65);
		Task task18 = new TaskNumeric("Write Proposal 2", 68, 100);
		task.addSubtask(task17);
		task.addSubtask(task18);
		Task task19 = new TaskNumeric("Obtain Approval", 65, 78);
		taskseries3.add(task);
		taskseries3.add(task19);
		
		
		TaskSeries taskseries2 = new TaskSeries("consume");
		Task task1 = new TaskNumeric("Write Proposal23123", 40, 100);
		taskseries2.add(task1);

		Task task2 = new TaskNumeric("Requirements", 40,100);
		Task task3 = new TaskNumeric("Requirements 1", 40, 55);
		Task task4 = new TaskNumeric("Requirements 2", 58, 75);
		task2.addSubtask(task3);
		task2.addSubtask(task4);
		taskseries2.add(task2);
		
		Task task21  =  new TaskNumeric("21", 60, 61);
		taskseries2.add(task21);
		
		Task task9 = new TaskNumeric("Design Signoff", 65, 75);
		taskseries2.add(task9);
		Task task10 = new TaskNumeric("Alpha Implementation", 65, 75);
		taskseries2.add(task10);
		Task task11 = new TaskNumeric("Design Review", 68, 69);
		taskseries2.add(task11);
		Task task13 = new TaskNumeric("Beta Implementation", 40, 69);
		taskseries2.add(task13);
		Task task14 = new TaskNumeric("Testing", 71, 78);
		taskseries2.add(task14);
		Task task15 = new TaskNumeric("Final Implementation", 68, 100);
		taskseries2.add(task15);
		Task task16 = new TaskNumeric("Signoff",75, 100);
		taskseries2.add(task16);
		Task task111 = new TaskNumeric("Signoff2", 95, 100);
		taskseries2.add(task111);
	
		model.add(taskseries3);
		model.add(taskseries2);

	TaskSeries taskseries4 = new TaskSeries("BBBB");
		Task task44 = new TaskNumeric("fill1", 40, 40);
		Task task45 = new TaskNumeric("fill2", 40, 40);
		Task task46 = new TaskNumeric("fill3", 40, 40);
		taskseries4.add(task44);
		taskseries4.add(task45);
		taskseries4.add(task46);
		model.add(taskseries4);
		
	/*	TaskSeries taskseries5 = new TaskSeries("AAAA");
		Task task55 = new Task("", date(1, 3, 2020), date(1, 3, 2050));
		taskseries5.add(task55);
		taskseriescollection.add(taskseries5);*/
	
		return model;
   
    }

    public static JPanel createDemoPanel() {
        JFreeChart jfreechart = createChart(createDataset());
        ChartPanel chartpanel = new ChartPanel(jfreechart);
        chartpanel.setMouseWheelEnabled(true);
        return chartpanel;
    }

    public static void main(String args[]) {
        GanttDemo4 ganttdemo = new GanttDemo4("gantt demo4");
        ganttdemo.pack();
        RefineryUtilities.centerFrameOnScreen(ganttdemo);
        ganttdemo.setVisible(true);
    }

}