// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 

package chart;

import java.awt.Color;
import java.awt.Dimension;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JPanel;
import org.jfree.chart.*;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.gantt.*;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;

import util.ChartUtils;
import util.MyGanttRenderer;

public class GanttDemo2 extends ApplicationFrame
{

	public GanttDemo2(String s)
	{
		super(s);
		JPanel jpanel = createDemoPanel();
		jpanel.setPreferredSize(new Dimension(500, 270));
		setContentPane(jpanel);
	}

	/**
	 * @param intervalcategorydataset
	 * @return
	 */
	private static JFreeChart createChart(IntervalCategoryDataset intervalcategorydataset)
	{
		JFreeChart jfreechart = ChartFactory.createGanttChart("Gantt Chart Demo", "Task", "Date", intervalcategorydataset, true, true, false);
		CategoryPlot categoryplot = (CategoryPlot)jfreechart.getPlot();
		categoryplot.setRangePannable(true);
		categoryplot.getDomainAxis().setMaximumCategoryLabelWidthRatio(10F);
	//	CategoryItemRenderer categoryitemrenderer = categoryplot.getRenderer();
	//	categoryitemrenderer.setSeriesPaint(0, Color.blue);
		MyGanttRenderer renderer = new MyGanttRenderer();
		categoryplot.setRenderer(renderer);
//		
		 renderer.setBaseItemLabelGenerator(new CategoryItemLabelGenerator() {

		      public String generateLabel(CategoryDataset dataset, int series, int categories) {
		       /* your code to get the label */
		          return String.valueOf(categories);

		      }

		      public String generateColumnLabel(CategoryDataset dataset, int categories) {
		         // return dataset.getColumnKey(categories).toString();
		    	  return null;
		      }

		      public String generateRowLabel(CategoryDataset dataset, int series) {
		         // return dataset.getRowKey(series).toString();
		    	  return null;
		      }
		 });

		 renderer.setBaseItemLabelsVisible(true);
		 renderer.setBasePositiveItemLabelPosition(new ItemLabelPosition(ItemLabelAnchor.OUTSIDE6, TextAnchor.CENTER));
		return jfreechart;
	}

	private static IntervalCategoryDataset createDataset()
	{
		TaskSeries taskseries = new TaskSeries("Scheduled");
		Task task = new Task("Write Proposal", date(1, 1, 2001), date(12, 12, 2001));
		task.setPercentComplete(1.0D);
		Task task17 = new Task("Write Proposal 1", date(1, 1, 2001), date(5,5, 2001));
		task.setPercentComplete(1.0D);
		Task task18 = new Task("Write Proposal 2", date(30, 5, 2001), date(6, 12, 2001));
		task.setPercentComplete(1.0D);

		task.addSubtask(task17);
		task.addSubtask(task18);
		
		taskseries.add(task);
		Task task1 = new Task("Obtain Approval", date(9, 3, 2001), date(9, 3, 2001));
		task1.setPercentComplete(1.0D);
		taskseries.add(task1);
		Task task2 = new Task("Requirements Analysis", date(10, 3, 2001), date(5, 4, 2001));
		Task task3 = new Task("Requirements 1", date(10, 3, 2001), date(25, 3, 2001));
		task3.setPercentComplete(1.0D);
		Task task4 = new Task("Requirements 2", date(1, 4, 2001), date(5, 4, 2001));
		task4.setPercentComplete(1.0D);
		task2.addSubtask(task3);
		task2.addSubtask(task4);
		taskseries.add(task2);
		Task task5 = new Task("Design Phase", date(6, 4, 2001), date(30, 4, 2001));
		task.setPercentComplete(0.0D);
		Task task6 = new Task("Design 1", date(6, 4, 2001), date(10, 4, 2001));
		task6.setPercentComplete(0.0D);
		Task task7 = new Task("Design 2", date(15, 4, 2001), date(20, 4, 2001));
		task7.setPercentComplete(0.0D);
		Task task8 = new Task("Design 3", date(23, 4, 2001), date(30, 4, 2001));
		task8.setPercentComplete(0.0D);
		task5.addSubtask(task6);
		task5.addSubtask(task7);
		task5.addSubtask(task8);
		taskseries.add(task5);
		Task task9 = new Task("Design Signoff", date(2, 5, 2001), date(2, 5, 2001));
		taskseries.add(task9);
		Task task10 = new Task("Alpha Implementation", date(3, 5, 2001), date(31, 6, 2001));
		task10.setPercentComplete(0.5D);
		taskseries.add(task10);
		Task task11 = new Task("Design Review", date(1, 7, 2001), date(8, 7, 2001));
		task11.setPercentComplete(0.0D);
		taskseries.add(task11);
		Task task12 = new Task("Revised Design Signoff", date(10, 7, 2001), date(10, 7, 2001));
		task12.setPercentComplete(0.0D);
		taskseries.add(task12);
		Task task13 = new Task("Beta Implementation", date(12, 7, 2001), date(12, 8, 2001));
		task13.setPercentComplete(0.0D);
		taskseries.add(task13);
		Task task14 = new Task("Testing", date(13, 8, 2001), date(31, 9, 2001));
		task14.setPercentComplete(0.0D);
		taskseries.add(task14);
		Task task15 = new Task("Final Implementation", date(1, 10, 2001), date(15, 10, 2001));
		task15.setPercentComplete(0.0D);
		taskseries.add(task15);
		Task task16 = new Task("Signoff", date(28, 10, 2001), date(30, 10, 2001));
		task16.setPercentComplete(0.0D);
		taskseries.add(task16);
		TaskSeriesCollection taskseriescollection = new TaskSeriesCollection();
		taskseriescollection.add(taskseries);
		TaskSeries taskseries2 = new TaskSeries("consume");
		Task task19 = new Task("Write Proposal23123", date(1, 3, 2001), date(5, 10, 2001));
		task.setPercentComplete(1.0D);
		taskseries2.add(task19);
		taskseriescollection.add(taskseries2);
/*		TaskSeries taskseries3 = new TaskSeries("BBBB");
		Task task20 = new Task("Write 12312323123", date(1, 3, 2001), date(5, 10, 2001));
		task.setPercentComplete(1.0D);
		taskseries3.add(task19);
		taskseriescollection.add(taskseries3);
		*/
		return taskseriescollection;
	}

	private static Date date(int i, int j, int k)
	{
		Calendar calendar = Calendar.getInstance();
		calendar.set(k, j, i);
		Date date1 = calendar.getTime();
		return date1;
	}

	public static JPanel createDemoPanel()
	{
		JFreeChart jfreechart = createChart(createDataset());
		ChartPanel chartpanel = new ChartPanel(jfreechart);
		chartpanel.setMouseWheelEnabled(true);
		return chartpanel;
	}

	public static void main(String args[])
	{
		
		
		GanttDemo2 ganttdemo2 = new GanttDemo2("JFreeChart: GanttDemo2.java");
		ganttdemo2.pack();
		RefineryUtilities.centerFrameOnScreen(ganttdemo2);
		ganttdemo2.setVisible(true);
	}
}
