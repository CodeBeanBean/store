// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 

package demo.hyron;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.geom.RectangularShape;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import org.jfree.chart.*;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.StandardBarPainter;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.gantt.*;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;

public class GanttDemo2 extends ApplicationFrame {
	static TaskSeries taskseries;

	public GanttDemo2(String s) {
		super(s);
		JPanel jpanel = createDemoPanel();
		jpanel.setPreferredSize(new Dimension(1200, 960));
		setContentPane(jpanel);
	}

	private static JFreeChart createChart(IntervalCategoryDataset intervalcategorydataset) {
		JFreeChart jfreechart = ChartFactory.createGanttChart("Gantt Chart Demo", "Task", "Date",
				intervalcategorydataset, true, true, false);
		CategoryPlot categoryplot = (CategoryPlot) jfreechart.getPlot();
		
		categoryplot.setBackgroundPaint(new Color(246 ,250, 252));
		MyGanttRenderer renderer = new MyGanttRenderer();
		categoryplot.setRenderer(renderer);		
	
		/*
		 * renderer.setBarPainter(new StandardBarPainter() {
		 * 
		 * @Override public void paintBar(Graphics2D g2, BarRenderer renderer, int row,
		 * int column, RectangularShape bar, RectangleEdge base) { BufferedImage
		 * xAxisImg = null; try { xAxisImg = ImageIO.read(new
		 * File("image/education48.png")); } catch (IOException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); } g2.drawImage(xAxisImg,
		 * bar.getBounds().x, bar.getBounds().y, null); }
		 * 
		 * public void paintBarShadow(Graphics2D g2, BarRenderer renderer, int row, int
		 * column, RectangularShape bar, RectangleEdge base, boolean pegShadow) { } });
		 */
	                
		renderer.setBaseItemLabelGenerator(new CategoryItemLabelGenerator() {

			//record main task index
			int row = -1;
			
			//record subtask index
			int col = 0;

			public String generateLabel(CategoryDataset dataSet, int series, int categories) { 
				System.out.println("series="+series + ",categories="+categories);


				Task task = (Task) taskseries.getTasks().get(categories);

				if(row != categories) {
					row = categories; 
					col = 0; 
				}
				
				if(task.getSubtaskCount()==0) { 
					return task.getDescription(); 
				} 
				
				//SubTask label
				String label = task.getSubtask(col++).getDescription(); 
				
				//reset row. prevent when only have one main task,repaint chart will skip [if(row != categories)].
				if(col == task.getSubtaskCount()) row = -1;

				return label; 
			}

			public String generateColumnLabel(CategoryDataset dataset, int categories) {
				return dataset.getColumnKey(categories).toString(); }

			public String generateRowLabel(CategoryDataset dataset, int series) { return
					dataset.getRowKey(series).toString(); }

		});

		renderer.setBaseItemLabelsVisible(true);
		renderer.setBasePositiveItemLabelPosition(
				new ItemLabelPosition(ItemLabelAnchor.CENTER, TextAnchor.CENTER));

		
		categoryplot.setRangePannable(true);
		categoryplot.getDomainAxis().setMaximumCategoryLabelWidthRatio(10F);
		CategoryItemRenderer categoryitemrenderer = categoryplot.getRenderer();
		categoryitemrenderer.setSeriesPaint(0, new Color(248,203,196));
		
		//categoryitemrenderer.setSeriesPaint(0, Color.blue);
		return jfreechart;
	}

	private static IntervalCategoryDataset createDataset() {
		taskseries = new TaskSeries("Scheduled");

		BufferedImage img1 = null;
		BufferedImage img2 = null;
		BufferedImage img3 = null;
		BufferedImage img4 = null;
		BufferedImage img5 = null;
		BufferedImage img6 = null;
		BufferedImage img7 = null;
		try {
			img1 = ImageIO.read(new File("src/image/medical48.png"));
			img2 = ImageIO.read(new File("src/image/car48.png"));
			img3 = ImageIO.read(new File("src/image/case48.png"));
			img4 = ImageIO.read(new File("src/image/pen48.png"));
			img5 = ImageIO.read(new File("src/image/care48.png"));
			img6 = ImageIO.read(new File("src/image/careerlife48.png"));
			img7 = ImageIO.read(new File("src/image/secondlife48.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		Task task1 = new Task("Task1", date(1, 3, 2001), date(5, 10, 2001));
		task1.setPercentComplete(1.0D);
		
		MyTask subtask1 = new MyTask("�L�����A���C�t", date(1, 3, 2001), date(5, 7, 2001));
		subtask1.setImage(img6);

		MyTask subtask2 = new MyTask("�Z�J���h���C�t", date(1, 8, 2001), date(5, 10, 2001));
		subtask2.setImage(img7);

		task1.addSubtask(subtask1);
		task1.addSubtask(subtask2);
		taskseries.add(task1);
		
		Task task2 = new Task("Task2", date(1, 3, 2001), date(5, 9, 2001));
		task1.setPercentComplete(1.0D);		

		MyTask subtask21 = new MyTask("��Â̗��p", date(10, 3, 2001), date(5, 9, 2001));
		subtask21.setImage(img1);
		task2.addSubtask(subtask21);
		taskseries.add(task2);

		Task task3 = new Task("Task3", date(1, 7, 2001), date(5, 10, 2001));
		task1.setPercentComplete(1.0D);		

		MyTask subtask31 = new MyTask("����������", date(10, 7, 2001), date(5, 10, 2001));
		subtask31.setImage(img5);
		task3.addSubtask(subtask31);
		taskseries.add(task3);
		
		Task task4 = new Task("Task4", date(1, 8, 2001), date(5, 10, 2001));
		task1.setPercentComplete(1.0D);		

		MyTask subtask41 = new MyTask("��������", date(10, 8, 2001), date(5, 10, 2001));
		subtask41.setImage(img4);
		task4.addSubtask(subtask41);
		taskseries.add(task4);
		
		/*
		 * Task task1 = new Task("Obtain Approval", date(9, 3, 2001), date(9, 7, 2001));
		 * task1.setPercentComplete(1.0D); taskseries.add(task1);
		 * 
		 * Task task2 = new Task("Requirements Analysis", date(10, 3, 2001), date(5, 10,
		 * 2001));
		 * 
		 * Task task3 = new Task("Requirements 1", date(10, 3, 2001), date(25, 5,
		 * 2001)); task3.setPercentComplete(1.0D);
		 * 
		 * Task task4 = new Task("Requirements 2", date(1, 7, 2001), date(5, 8, 2001));
		 * task4.setPercentComplete(1.0D);
		 * 
		 * Task task5 = new Task("Requirements 3", date(1, 9, 2001), date(5, 10, 2001));
		 * task5.setPercentComplete(1.0D);
		 * 
		 * task2.addSubtask(task3); task2.addSubtask(task4); task2.addSubtask(task5);
		 * taskseries.add(task2);
		 * 
		 * Task task6 = new Task("Design Phase", date(6, 4, 2001), date(30, 11, 2001));
		 * 
		 * taskseries.add(task6);
		 */

		/*
		 * 
		 * Task task6 = new Task("Design 1", date(6, 4, 2001), date(10, 4, 2001));
		 * task6.setPercentComplete(1.0D); Task task7 = new Task("Design 2", date(15, 6,
		 * 2001), date(20, 7, 2001)); task7.setPercentComplete(1.0D); Task task8 = new
		 * Task("Design 3", date(23, 10, 2001), date(30, 11, 2001));
		 * task8.setPercentComplete(0.5D); task5.addSubtask(task6);
		 * task5.addSubtask(task7); task5.addSubtask(task8); taskseries.add(task5); Task
		 * task9 = new Task("Design Signoff", date(2, 5, 2001), date(2, 5, 2001));
		 * taskseries.add(task9); Task task10 = new Task("Alpha Implementation", date(3,
		 * 5, 2001), date(31, 6, 2001));
		 * task10.setPercentComplete(0.59999999999999998D); taskseries.add(task10); Task
		 * task11 = new Task("Design Review", date(1, 7, 2001), date(8, 7, 2001));
		 * task11.setPercentComplete(0.0D); taskseries.add(task11); Task task12 = new
		 * Task("Revised Design Signoff", date(10, 7, 2001), date(10, 7, 2001));
		 * task12.setPercentComplete(0.0D); taskseries.add(task12); Task task13 = new
		 * Task("Beta Implementation", date(12, 7, 2001), date(12, 8, 2001));
		 * task13.setPercentComplete(0.0D); taskseries.add(task13); Task task14 = new
		 * Task("Testing", date(13, 8, 2001), date(31, 9, 2001));
		 * task14.setPercentComplete(0.0D); taskseries.add(task14); Task task15 = new
		 * Task("Final Implementation", date(1, 10, 2001), date(15, 10, 2001));
		 * task15.setPercentComplete(0.0D); taskseries.add(task15); Task task16 = new
		 * Task("Signoff", date(28, 10, 2001), date(30, 10, 2001));
		 * task16.setPercentComplete(0.0D); taskseries.add(task16);
		 */
		TaskSeriesCollection taskseriescollection = new TaskSeriesCollection();
		taskseriescollection.add(taskseries);
		return taskseriescollection;
	}

	private static Date date(int i, int j, int k) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(k, j, i);
		Date date1 = calendar.getTime();
		return date1;
	}

	public static JPanel createDemoPanel() {
		JFreeChart jfreechart = createChart(createDataset());
		ChartPanel chartpanel = new ChartPanel(jfreechart);
		chartpanel.setMouseWheelEnabled(true);
		return chartpanel;
	}

	public static void main(String args[]) {
		GanttDemo2 ganttdemo2 = new GanttDemo2("JFreeChart: GanttDemo2.java");
		ganttdemo2.pack();		
		ganttdemo2.setVisible(true);
		//RefineryUtilities.centerFrameOnScreen(ganttdemo2);
		
	}
}
