package demo.hyron;

import java.awt.image.BufferedImage;
import java.util.Date;

import org.jfree.data.gantt.Task;

public class MyTask extends Task{
	
	private BufferedImage image;

	public MyTask(String description, Date start, Date end) {
		super(description, start, end);
		// TODO Auto-generated constructor stub
	}
	
	public MyTask(String description, Date start, Date end , BufferedImage img) {
		super(description, start, end);
		this.image = img;
		// TODO Auto-generated constructor stub
	}
	
	public void setImage( BufferedImage img) {
		this.image = img;
	}
	
	public BufferedImage getImage() {
		return this.image;
	}

}
